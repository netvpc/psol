#define INCLUDE2_STRING "inc2/include2.h"
