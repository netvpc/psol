#define DEEPER_STRING   "subdir2/deeper/deeper.h"
